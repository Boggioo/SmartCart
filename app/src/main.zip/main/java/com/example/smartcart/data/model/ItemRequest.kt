package com.example.smartcart.data.model

data class ItemRequest(
    val name: String,
    val quantity: Int
)
