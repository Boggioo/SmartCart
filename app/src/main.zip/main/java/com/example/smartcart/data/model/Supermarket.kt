package com.example.smartcart.data.model

data class Supermarket(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val distance: Double
)
