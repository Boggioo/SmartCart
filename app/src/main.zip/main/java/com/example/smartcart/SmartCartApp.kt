package com.example.smartcart
import android.app.Application
class SmartCartApp : Application()
