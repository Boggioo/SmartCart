package com.example.smartcart.data.model
data class Suggestion(
    val name: String,
    val weight: Int
)
