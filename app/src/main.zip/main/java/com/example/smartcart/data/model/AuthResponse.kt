package com.example.smartcart.data.model
data class AuthResponse(
    val access_token: String,
    val user_id: Int
)
